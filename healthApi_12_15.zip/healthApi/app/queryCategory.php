<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class queryCategory extends Model
{
    //
}
