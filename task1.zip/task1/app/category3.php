<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category3 extends Model
{
    //
}
