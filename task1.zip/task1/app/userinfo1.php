<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userinfo1 extends Model
{
    //
}
