<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class instructions extends Model
{
    //
}
