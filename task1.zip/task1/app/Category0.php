<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category0 extends Model
{
    //
}
