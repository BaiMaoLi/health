

@extends('user.template')
<link rel="stylesheet" type="text/css" href="{{asset('public/user/css/edit_profile.css')}}">
@section('content')
    <script type="text/css">
        .white{
        background:white;
        }
    </script>

    <form role="form" id="form" action="{{ route('userprofile.update','1') }}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
        {{ method_field('PUT') }}
        <div class="edit-profile-main">
        @if (!is_null($profile))
            <div id="photo-part">
                <div id="user-photo-part">
                    <div class="image-upload">
                        <label for="profile_picture">
                            @if (!is_null($profile->profile_picture))
                                <img src="{{$profile->profile_picture}}" id="user-photo">
                            @else
                                <img src="{{asset('public/user/images/profile_pictures/avatar.jpg')}}" id="user-photo">
                            @endif
                        </label>
                        <input type="file" id="profile_picture" name="profile_picture" class="form-control" style="display:none;" disabled/>
                    </div>
                    <h4 id="employee-name-edit">{{ $user['first_name']." ".$user->last_name }}</h4>
                    <div class="row">
                        <h4 id="employee-id-title">Employee ID</h4>
                        <h4 id="employee-id-number-edit">{{ $user['employee_number']}}</h4>
                    </div>
                </div>
                <div id="coach-photo-part" style="display:none">
                    <img src="{{asset('public/user/images/coach_photo.png')}}" id="coach-photo">
                    <h4 id="coach_kind">MY WELLNESS COACH</h4>
                    <h4 id="coach_name">TALEI BERGER</h4>
                </div>
                <button id="message-my-coach" style="display:none">MESSAGE MY COACH</button>

            </div>
            <div class="information-part">
                <i class="demo-icon icon-edit_profile" aria-hidden="true" id="user-profile-icon"></i>
                <span id="personal-profile">PERSONAL PROFILE</span>
                <div class="name-information">
                    <div class="row">
                        <h4 class="information-label">First Name:</h4>
                        <input class="information" name="first_name" value="{{ $user->first_name}}">
                    </div>

                    <div class="row">
                        <h4 class="information-label">Last Name:</h4>
                        <input class="information" name="last_name" value="{{ $user->last_name}}">
                    </div>


                    <div class="row">
                        <h4 class="information-label">Employee ID:</h4>
                        <input class="information" name="employee_id" value="{{ $user->employee_number}}">
                    </div>
                </div>

                <div class="address-information">
                    <div class="row">
                        <h4 class="information-label">Address:</h4>
                        <input class="information" name="address" value="{{$profile->address}}">
                    </div>
                    <div class="row">
                        <h4 class="information-label">City:</h4>
                        <input class="information" name="city" value="{{$profile->city}}">
                    </div>
                    <div class="row">
                        <h4 class="information-label">State:</h4>
                        <input class="information" name="state"  value="{{$profile->state}}">
                    </div>
                    <div class="row">
                        <h4 class="information-label">Zip:</h4>
                        <input class="information" name="zip" value="{{$profile->zip}}">
                    </div>
                </div>

                <div class="email-information">
                    <div class="row">
                        <h4 class="information-label">Email:</h4>
                        <input class="information" name="email" value="{{$user->email}}">
                    </div>
                    <div class="row">
                        <h4 class="information-label">Phone:</h4>
                        <input class="information" name="phone" value="{{$profile->phone}}">
                    </div>

                </div>

                <div class="birthday-information">
                    <div class="row">
                        <h4 class="information-label">Birthday:</h4>
                        <input class="information" name="birthday" value="{{$profile->birthday}}" placeholder="1991/01/26">
                    </div>
                    <div class="row">
                        <h4 class="information-label">Gender:</h4>
                        <input class="information" name="gender" id="gender-display" value="{{$profile->gender}}">
                        <select class="information" name="gender" id="gender-select"  style="display: none">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>

                </div>
                <input type="submit" id="edit-profile" value="EDIT"></input>
                <div class="v-edit-profile"></div>
            </div>
        @else
                <div id="photo-part">
                    <div id="user-photo-part">
                        <div class="image-upload">
                            <label for="profile_picture">
                                <img src="{{asset('public/user/images/profile_pictures/avatar.jpg')}}" id="user-photo">
                            </label>
                            <input type="file" id="profile_picture" name="profile_picture" class="form-control" style="display:none;" disabled/>
                        </div>
                        <h4 id="employee-name-edit">{{ $user['first_name']." ".$user->last_name }}</h4>
                        <div class="row">
                            <h4 id="employee-id-title">Employee ID</h4>
                            <h4 id="employee-id-number-edit">{{ $user['employee_number']}}</h4>
                        </div>
                    </div>
                    <div id="coach-photo-part">
                        <img src="{{asset('public/user/images/coach_photo.png')}}" id="coach-photo">
                        <h4 id="coach_kind">MY WELLNESS COACH</h4>
                        <h4 id="coach_name">TALEI BERGER</h4>
                    </div>
                    <button id="message-my-coach">MESSAGE MY COACH</button>

                </div>
                <div class="information-part">
                    <i class="demo-icon icon-edit_profile" aria-hidden="true" id="user-profile-icon"></i>
                    <span id="personal-profile">PERSONAL PROFILE</span>
                    <div class="name-information">
                        <div class="row">
                            <h4 class="information-label">First Name:</h4>
                            <input class="information" name="first_name" value="{{ $user->first_name}}">
                        </div>
                        <div class="row">
                            <h4 class="information-label">Last Name:</h4>
                            <input class="information" name="last_name" value="{{ $user->last_name}}">
                        </div>

                        <div class="row">
                            <h4 class="information-label">Employee ID:</h4>
                            <input class="information" name="employee_id" value="{{ $user->employee_number}}">
                        </div>
                    </div>

                    <div class="address-information">
                        <div class="row">
                            <h4 class="information-label">Address:</h4>
                            <input class="information" name="address" >
                        </div>
                        <div class="row">
                            <h4 class="information-label">City:</h4>
                            <input class="information" name="city" >
                        </div>
                        <div class="row">
                            <h4 class="information-label">State:</h4>
                            <input class="information" name="state" >
                        </div>
                        <div class="row">
                            <h4 class="information-label">Zip:</h4>
                            <input class="information" name="zip">
                        </div>
                    </div>

                    <div class="email-information">
                        <div class="row">
                            <h4 class="information-label">Email:</h4>
                            <input class="information" name="email" value="{{$user->email}}">
                        </div>
                        <div class="row">
                            <h4 class="information-label">Phone:</h4>
                            <input class="information" name="phone" >
                        </div>

                    </div>

                    <div class="birthday-information">
                        <div class="row">
                            <h4 class="information-label">Birthday:</h4>
                            <input class="information" name="birthday" >
                        </div>
                        <div class="row">
                            <h4 class="information-label">Gender:</h4>
                            <input type="text" class="information" name="gender" >
                        </div>

                    </div>
                    <input type="submit" id="edit-profile" value="EDIT"></input>
                    <div class="v-edit-profile"></div>
                </div>
        @endif
        </div>
        </form>





<script type="text/javascript">
    var i=0;
    $(document).ready(function() {
    $('.information').prop("disabled", true);
    });


    jQuery("#edit-profile").click(function() {
        var btn = document.getElementById('edit-profile');
        $(this).val('Save');

        $('#gender-display').hide();
        $('#gender-select').show();

        $('.information').prop("disabled", false);
        var information=document.getElementsByClassName('information');
        for ( var i=0; i<information.length; i++ ) {
            information[i].style.backgroundColor = "white";
        }
        document.getElementById("profile_picture").disabled =false;
        document.getElementById('user-photo').style.cursor="pointer";

    });
    $('#form').submit(function(e) {
        var name=document.getElementById('edit-profile').value;
        if (i==0) {
            e.preventDefault();            // document.getElementById('edit-profile').val('Save');
        }
        else
            return true;
        i++;
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#user-photo').attr('src', e.target.result);

            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile_picture").change(function(){
        document.getElementById("user-photo").style.width="180px";
        readURL(this);
    });
</script>
@endsection


























